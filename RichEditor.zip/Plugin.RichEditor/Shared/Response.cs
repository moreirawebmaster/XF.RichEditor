﻿namespace Plugin.RichEditor.Shared
{
    public class Response
    {
        public bool IsSave { get; set; }
        public string Html { get; set; }
    }
}